window.onload=function(){
	 var am=$("html").css("font-size",$("body").width()/640*100+"px");
	$(window).resize(am);
}
/*用户页面*/
$(document).ready(function(){
    $("#username").click(function(){
        $(".theme-popover-mask").show(300);
        $(".Prompt").show(500);
    })
    $(".theme-popover-mask").click(function(){
        $(".theme-popover-mask").hide(500);
        $(".Prompt").hide(300);
    })
    $(".Prompt>ul>li>a").click(function(){
        $(".theme-popover-mask").hide(500);
        $(".Prompt").hide(300);
    })
})
$(".dynamic .bd>i").click(function(){
    
})


