window.onload=function(){
	 var am=$("html").css("font-size",$("body").width()/640*100+"px");
	$(window).resize(am);
}